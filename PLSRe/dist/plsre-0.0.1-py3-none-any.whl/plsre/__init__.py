#The entry of plsre
import plsre.PlsRegression
